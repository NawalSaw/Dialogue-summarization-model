import torch
import torch.nn as nn
from torch.utils.data import DataLoader
from torch.utils.tensorboard import SummaryWriter

from pathlib import Path

from dataset import SamsumDataset, causal_mask
from tokeniser.tokeniser import get_or_create_tokenizer
from datasets import load_dataset, concatenate_datasets
from tqdm import tqdm

from transformer import build_transformer
from config import get_config
from config import get_weights_path

def greedy_decode(model, tokenizer, source, source_mask, max_len, device):
    bos_token_id = tokenizer.token_to_id("[BOS]")
    eos_token_id = tokenizer.token_to_id("[EOS]")
    
    # Precomputing
    encoder_output = model.encode(source, source_mask)
    
    # Start with BOS token
    decoder_input = torch.tensor([[bos_token_id]], dtype=torch.int64, device=device) # shape (1, 1)
    
    # Generate tokens
    while True:
        if decoder_input.size(1) > max_len:
            break

        # Prepare decoder mask
        decoder_mask = causal_mask(decoder_input.size(1)).type_as(source_mask).to(device)
        
        # Get decoder output
        decoder_output = model.decode(decoder_input, encoder_output, source_mask, decoder_mask) # shape (1, seq_len, d_model)
        
        # Get next token
        next_token_probs = model.project(decoder_output[:, -1, :]) # shape (1, vocab_size)
        _, next_token = torch.max(next_token_probs, dim=-1, keepdim=True) # shape (1, 1)
        
        # Check for EOS
        if next_token.item() == eos_token_id:
            break
            
        # Append to decoder input
        decoder_input = torch.cat([decoder_input, torch.empty(1, 1, dtype=torch.int64, device=device).type_as(source).fill_(next_token.item())], dim=1)
    
    return decoder_input.squeeze(0)
    
def evaluate_model(model, tokenizer, max_len, validation_dataset, device, print_msg, num_example=2):
    model.eval()
    count = 0

    console_width = 80

    with torch.no_grad():
        for batch in validation_dataset:
            if count >= num_example:
                break
            count += 1

            encoder_input = batch["encoder_input"].to(device)
            encoder_mask = batch["encoder_mask"].to(device)

            assert encoder_input.size(0) == 1, "Batch size must be 1 for evaluation"

            model_out = greedy_decode(model, tokenizer, encoder_input, encoder_mask, max_len, device)
            
            source_text = batch["src_text"][0]
            target_text = batch["trg_text"][0]
            model_out_text = tokenizer.decode(model_out.detach().cpu().numpy())

            print_msg(f"{'SOURCE':>12}: {source_text}")
            print_msg(f"{'TARGET':>12}: {target_text}")
            print_msg(f"{'PREDICTED':>12}: {model_out_text}")

            print_msg("=" * console_width)
            
def get_dataset_tokenizer(config):
    dataset = load_dataset("knkarthick/samsum")

    train_dataset = dataset['train']
    val_dataset = dataset['validation']
    test_dataset = dataset['test']

    com_dataset = concatenate_datasets([dataset['train'], dataset["validation"], dataset["test"]])

    tokenizer = get_or_create_tokenizer(config, com_dataset, config["batch_size"])

    train_dataset = SamsumDataset(train_dataset, tokenizer, config["seq_len"])
    val_dataset = SamsumDataset(val_dataset, tokenizer, config["seq_len"])
    test_dataset = SamsumDataset(test_dataset, tokenizer, config["seq_len"])

    max_length_src = 0
    max_length_tgt = 0
    
    for item in com_dataset:
        src_ids = tokenizer.encode(item["dialogue"]).ids
        tgt_ids = tokenizer.encode(item["summary"]).ids

        max_length_src = max(max_length_src, len(src_ids))
        max_length_tgt = max(max_length_tgt, len(tgt_ids))
    
    train_dataloader = DataLoader(train_dataset, batch_size=config["batch_size"], shuffle=True)
    val_dataloader = DataLoader(val_dataset, batch_size=1, shuffle=False)
    test_dataloader = DataLoader(test_dataset, batch_size=1, shuffle=False)

    return train_dataloader, val_dataloader, test_dataloader, tokenizer

def get_model(config, vocab_size):
    model = build_transformer(config["d_model"], config["heads_num"], config["dropout"], vocab_size, config["num_layers"], config["seq_len"])
    return model

def train_model(config):
    # Set the device
    device = "cuda" if torch.cuda.is_available() else "cpu"
    print("Using device:", device)

    Path(config["model_folder"]).mkdir(parents=True, exist_ok=True)

    train_dataloader, val_dataloader, test_dataloader, tokenizer = get_dataset_tokenizer(config)
    model = get_model(config, tokenizer.get_vocab_size()).to(device)

    writer = SummaryWriter(config["experiment_name"])

    optimiser = torch.optim.Adam(model.parameters(), lr=config["lr"], eps=1e-9)

    intial_epoch = 0
    global_step = 0

    num_params = sum(p.numel() for p in model.parameters())
    print(f"Number of parameters: {num_params:,}")
    print(f"vocabulary size: {tokenizer.get_vocab_size()}")

    if config['preload']:
        model_filename = get_weights_path(config, config['preload'])
        print(f"Preloading model {model_filename}")

        state = torch.load(model_filename)
        model.load_state_dict(state['model_state_dict'])

        intial_epoch = state['epoch'] + 1
        optimiser.load_state_dict(state['optimizer_state_dict'])

        global_step = state['global_step']
        print(f"Preloaded model from epoch {intial_epoch - 1}")
        print(f"Global step: {global_step}")

    loss_fn = torch.nn.CrossEntropyLoss(ignore_index=tokenizer.token_to_id('[PAD]'), label_smoothing=0.1).to(device)

    for epoch in range(intial_epoch, config["num_epochs"]):
        model.train()
        # batch_iter = tqdm(train_dataloader, desc=f"Epoch {epoch:02d}")

        for batch in train_dataloader:
            encoder_input = batch["encoder_input"].to(device)
            decoder_input = batch["decoder_input"].to(device)
            encoder_mask = batch["encoder_mask"].to(device)
            decoder_mask = batch["decoder_mask"].to(device)
            label = batch["label"].to(device)

            # Run the tensors through the encoder, decoder and the projection layer
            encoder_output = model.encode(encoder_input, encoder_mask) # (batch_size, seq_len, d_model)
            decoder_output = model.decode(decoder_input, encoder_output, encoder_mask, decoder_mask) # (batch_size, seq_len, d_model)
            proj_output = model.project(decoder_output) # (batch_size, seq_len, vocab_size)
            
            loss = loss_fn(proj_output.reshape(-1, tokenizer.get_vocab_size()), label.reshape(-1))
            batch_iter.set_postfix({"loss": f"{loss.item():6.3f}"})

            writer.add_scalar('train_loss', loss.item(), global_step)
            writer.flush()

            loss.backward()
            optimiser.step()
            optimiser.zero_grad()

            global_step += 1

        checkpoint_path = get_weights_path(config, f"{epoch:02d}")
        torch.save({
            "epoch": epoch,
            "model_state_dict": model.state_dict(),
            "optimizer_state_dict": optimiser.state_dict(),
            "global_step": global_step
        }, checkpoint_path)

        evaluate_model(model, tokenizer, config["seq_len"], val_dataloader, device, lambda x: batch_iter.write(x))

    model_path = get_weights_path(config, f"final_{epoch}")
    torch.save({
        'epoch': epoch,
        'model_state_dict': model.state_dict(),
        'optimizer_state_dict': optimiser.state_dict(),
        'global_step': global_step
    }, model_path)

    writer.close()
    print(f"Model saved to {model_path}")
    

if __name__ == "__main__":
    config = get_config()
    train_model(config)
